package controlador;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import database.query;
import recursos.parametrizable;
import vista.index;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class logica implements parametrizable{
	private index panel;
	private query sql = new query("com.mysql.cj.jdbc.Driver", "localhost", "3306" , "empresa_vh", "root", "");
	private String pattern = "#.##";
	private JButton btn_lista_1;
	DecimalFormat decimalFormat =  new DecimalFormat(pattern);
	public logica() {}
	
	public logica(index panel) {
		this.panel = panel;
	}
	
	public String getUsername(String username) {
		String username_ = "";
		ResultSet res = sql.getQuery("SELECT username FROM usuario WHERE username = '"+ username +"'");
		try {
			while(res.next()) {
				username_ = res.getString(1);
				return username_;
			}
			sql.cerrarConn();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error en la consulta de Generos");
		}
		return username_;
	}
	
	public void login() {
		String username = panel.txt_username.getText().toString();
		String password = new String(panel.txt_password.getPassword());
		ResultSet res = sql.getQuery("SELECT cid, username, password FROM usuario WHERE username = '"+ username +"' AND password = '"+ password +"'");
		try {
			if(res.next()) {
				panel.registro.setVisible(false);
				panel.lista.setVisible(true);
				panel.vehiculo.setVisible(false);
				panel.vender.setVisible(false);
				panel.login.setVisible(false);
				panel.lbl_username.setText(getUsername(username));
				panel.lbl_cedula.setText(res.getString(1));
				try {
					File file = new File("logs.txt");
					if (!file.exists()) {
		                file.createNewFile();
		            }
		            FileWriter fw = new FileWriter(file);
		            BufferedWriter bw = new BufferedWriter(fw);
		            bw.write("Nombre usuario: " + username + " Contrase�a: " + password);
		            bw.close();
				} catch (Exception e) {
		            e.printStackTrace();
		        }
				
			}else {
				print("Credenciales incorrectas");
			}
			sql.cerrarConn();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error en la consulta de Generos");
		}
	}
	
	public void register() {
		String cid = panel.txt_cid.getText().toString();
		String nombres = panel.txt_nombres.getText().toString();
		String apellidos = panel.txt_apellidos.getText().toString();
		String username = panel.txt_username_reg.getText().toString();
		String password = new String(panel.txt_password_reg.getPassword());
		String password_conf = new String(panel.txt_password_reg_conf.getPassword());
		print(username + " " + cid + " " + nombres + " " + apellidos + " " + password + " " + password_conf);
		if(password.equals(password_conf)) {
			if(sql.setQuery("INSERT INTO usuario VALUES ('"+ cid +"', '"+ nombres +"', '"+ apellidos +"', '"+ username +"', '"+ password +"')")) {
				print("Registro exitoso.");
			}else {
				print("No se pudo realizar el registro.");
			}
		}else {
			print("Las contrase�as no coinciden.");
		}
	}
	
	public double calcularPrecioReal(double valor_venta, int anio, double kilometraje, int num_duenos, String choques, String aire_acon, String tapiceria, String pintura, String carroceria) {
		double calculo = valor_venta;
		if(kilometraje > 80000) {
			calculo -= (calculo * 0.025);
		}
		if(num_duenos > 1) {
			calculo -= (calculo * 0.02);
		}
		if(choques.equals("Si")) {
			calculo -= (calculo * 0.15);
		}
		if(aire_acon.equals("No")) {
			calculo -= (calculo * 0.005);
		}
		//Tapiceria
		if(tapiceria.equals("Excelente")) {
			calculo += (calculo * 0.01);
		}else if(tapiceria.equals("Regular")) {
			calculo -= (calculo * 0.015);
		}else if(tapiceria.equals("Mala")) {
			calculo -= (calculo * 0.03);
		}
		//Pintura
		if(pintura.equals("Excelente")) {
			calculo += (calculo * 0.02);
		}else if(pintura.equals("Regular")) {
			calculo -= (calculo * 0.02);
		}else if(pintura.equals("Mala")) {
			calculo -= (calculo * 0.1);
		}
		//Carroceria
		if(carroceria.equals("Excelente")) {
			calculo += (calculo * 0.02);
		}else if(carroceria.equals("Regular")) {
			calculo -= (calculo * 0.02);
		}else if(carroceria.equals("Mala")) {
			calculo -= (calculo * 0.1);
		}
		return calculo;
	}
	
	public void getDatosVH(String id_vh) {
		panel.login.setVisible(false);
		panel.vehiculo.setVisible(true);
		panel.vender.setVisible(false);
		panel.registro.setVisible(false);
		panel.lista.setVisible(false);
		ResultSet res = sql.getQuery("SELECT * FROM vehiculo WHERE id_vh = '"+ id_vh +"'");
		try {
			while(res.next()) {
				panel.lbl_datos_vh_marca.setText("Marca: " + res.getString(3));
				panel.lbl_datos_vh_modelo.setText("Modelo: " + res.getString(4));
				panel.lbl_datos_vh_anio.setText("A�o: " + res.getString(5));
				panel.lbl_datos_vh_kilometraje.setText("Kilometraje: " + res.getString(6) + "km");
				panel.lbl_datos_vh_nduenos.setText("N�mero de due�os: " + res.getString(8));
				panel.lbl_datos_vh_aire_acon.setText("Aire acondicionado: " + res.getString(10));
				panel.lbl_datos_vh_tapiceria.setText("Tapiceria: " + res.getString(11));
				panel.lbl_datos_vh_pintura.setText("Pintura: " + res.getString(12));
				panel.lbl_datos_vh_carroceria.setText("Carroceria: " + res.getString(13));
				panel.lbl_datos_vh_choques.setText("Choques: " + res.getString(9));
				panel.lbl_datos_vh_valor_venta.setText("Valor de venta: $" + res.getString(7));
				String formattedDouble = decimalFormat.format(calcularPrecioReal(res.getDouble(7), res.getInt(5), res.getDouble(6), res.getInt(8), res.getString(9), res.getString(10), res.getString(11), res.getString(12), res.getString(13)));
				panel.lbl_datos_valor_venta_desc.setText("Valor de venta real: $" + formattedDouble);
				Icon icono = null;
				ImageIcon fot = new ImageIcon(res.getString(14));
				icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_imagen_vh.getWidth(), panel.lbl_imagen_vh.getHeight(), Image.SCALE_DEFAULT));
				panel.lbl_imagen_vh.setIcon(icono);
				panel.lbl_id_vh.setText(id_vh);
			}
			sql.cerrarConn();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error en la consulta de vehiculos.");
		}
	}
	
	public void saveVH() {
		String cid = panel.lbl_cedula.getText().toString();
		String marca = panel.txt_marca.getText().toString();
		String modelo = panel.txt_modelo.getText().toString();
		String anio = panel.cmb_anio.getSelectedItem().toString();
		float kilometraje = (float) panel.txt_kilometraje.getValue();
		float valor_venta = (float) panel.txt_valor_venta.getValue();
		int num_duenos = (int) panel.txt_num_duenos.getValue();
		String choques = panel.cmb_choques.getSelectedItem().toString();
		String aire_acon = panel.cmb_aire_acon.getSelectedItem().toString();
		String tapiceria = panel.cmb_tapiceria.getSelectedItem().toString();
		String pintura = panel.cmb_pintura.getSelectedItem().toString();
		String carroceria = panel.cmb_carroceria.getSelectedItem().toString();
		String ruta = panel.ruta;
		String [] parts = ruta.split("");
		String newRuta = "";
		for(int i = 0; i < parts.length; i++) {
			newRuta = newRuta + parts[i].replace("\\", "//");
		}	
		if(sql.setQuery("INSERT INTO vehiculo VALUES (null, '"+ cid +"', '"+ marca +"', '"+ modelo +"', '"+ anio +"', '"+ kilometraje +"', '"+ valor_venta +"', '"+ num_duenos +"', '"+ choques +"', '"+ aire_acon +"', '"+ tapiceria +"', '"+ pintura +"', '"+ carroceria +"', '"+ newRuta +"')")) {
			print("Registro exitoso.");
			cargar_lista();
		}else {
			print("No se pudo realizar el registro.");
		}
	}
	
	public void saveCompra(String cid, String id_vh) {
		if(sql.setQuery("INSERT INTO compras VALUES (null, '"+ cid +"', '"+ id_vh +"')")) {
			print("Se registr� su compra.");
		}else {
			print("No se pudo realizar el registro.");
		}
	}
	
	public void cargar_lista() {
		panel.login.setVisible(false);
		panel.vehiculo.setVisible(false);
		panel.vender.setVisible(false);
		panel.registro.setVisible(false);
		panel.lista.setVisible(true);
		ResultSet res = sql.getQuery("SELECT * FROM vehiculo");
		int i = 0;
		try {
			while(res.next()) {
				if(i == 0) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_1.getWidth(), panel.lbl_lista_1.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_1.setIcon(icono);
					panel.lbl_lista_1_1.setText(res.getString(1));
				}else if(i == 1) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_2.getWidth(), panel.lbl_lista_2.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_2.setIcon(icono);
					panel.lbl_lista_1_2.setText(res.getString(1));
				}else if(i == 2) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_3.getWidth(), panel.lbl_lista_3.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_3.setIcon(icono);
					panel.lbl_lista_1_3.setText(res.getString(1));
				}else if(i == 3) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_4.getWidth(), panel.lbl_lista_4.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_4.setIcon(icono);
					panel.lbl_lista_1_4.setText(res.getString(1));
				}else if(i == 4) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_5.getWidth(), panel.lbl_lista_5.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_5.setIcon(icono);
					panel.lbl_lista_1_5.setText(res.getString(1));
				}else if(i == 5) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_6.getWidth(), panel.lbl_lista_6.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_6.setIcon(icono);
					panel.lbl_lista_1_6.setText(res.getString(1));
				}else if(i == 6) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_7.getWidth(), panel.lbl_lista_7.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_7.setIcon(icono);
					panel.lbl_lista_1_7.setText(res.getString(1));
				}else if(i == 7) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_8.getWidth(), panel.lbl_lista_8.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_8.setIcon(icono);
					panel.lbl_lista_1_8.setText(res.getString(1));
				}else if(i == 8) {
					Icon icono = null;
					ImageIcon fot = new ImageIcon(res.getString(14));
					icono = new ImageIcon(fot.getImage().getScaledInstance(panel.lbl_lista_9.getWidth(), panel.lbl_lista_9.getHeight(), Image.SCALE_DEFAULT));
					panel.lbl_lista_9.setIcon(icono);
					panel.lbl_lista_1_9.setText(res.getString(1));
				}
				i++;
			}
			sql.cerrarConn();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error en la consulta de vehiculos.");
		}
	}
}
