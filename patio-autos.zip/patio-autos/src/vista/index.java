package vista;

import javax.swing.JPanel;
import java.awt.TextField;
import java.awt.Button;
import java.awt.SystemColor;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import controlador.logica;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.JButton;
import java.awt.event.TextListener;
import java.awt.event.TextEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JTextField;

public class index extends JPanel {

	private logica lg;
	public TextField txt_username;
	public JPasswordField txt_password;
	public JPanel vehiculo;
	public JPanel login;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel icono;
	public JLabel lbl_datos_vh_marca;
	private Button button_1;
	public JLabel lbl_datos_vh_modelo;
	public JLabel lbl_datos_vh_anio;
	public JLabel lbl_datos_vh_kilometraje;
	public JLabel lbl_datos_vh_nduenos;
	public JLabel lbl_datos_vh_aire_acon;
	public JLabel lbl_datos_vh_tapiceria;
	public JLabel lbl_datos_vh_pintura;
	public JLabel lbl_datos_vh_carroceria;
	public JLabel lbl_datos_vh_choques;
	public JLabel lbl_datos_vh_valor_venta;
	public JLabel lbl_imagen_vh;
	private Button button_2;
	private Button button_3;
	private Button button_4;
	public JPanel registro;
	public JPasswordField txt_password_reg;
	public JPasswordField txt_password_reg_conf;
	public TextField txt_cid, txt_nombres, txt_apellidos, txt_username_reg;
	private Button button_6;
	private Button button_7;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	public JLabel lbl_username;
	public TextField txt_marca;
	public TextField txt_modelo;
	public String ruta = "";
	private JLabel lbl_imagen;
	private JLabel lblNewLabel_10;
	private JLabel lbl_marca_v;
	private JLabel lbl_modelo_v;
	private JLabel lbl_anio_v;
	private JLabel lbl_kilometraje_v;
	private JLabel lbl_num_duenos_v;
	private JLabel lbl_choques_v;
	private JLabel lbl_aire_acon_v;
	private JLabel lbl_tapiceria_v;
	private JLabel lbl_pintura_v;
	private JLabel lbl_carroceria_v;
	private JLabel lbl_valor_venta;
	public JPanel vender;
	private Button button_9;
	public JComboBox cmb_anio;
	public JSpinner txt_num_duenos;
	public JComboBox cmb_choques;
	public JComboBox cmb_aire_acon;
	public JComboBox cmb_tapiceria;
	public JComboBox cmb_pintura;
	public JComboBox cmb_carroceria;
	public JSpinner txt_valor_venta;
	public JSpinner txt_kilometraje;
	public JLabel lbl_cedula;
	public JLabel lbl_datos_valor_venta_desc;
	public JPanel lista;
	public JLabel lbl_lista_1;
	public JLabel lbl_lista_2;
	public JLabel lbl_lista_3;
	public JLabel lbl_lista_4;
	public JLabel lbl_lista_5;
	public JLabel lbl_lista_6;
	public JLabel lbl_lista_7;
	public JLabel lbl_lista_8;
	public JLabel lbl_lista_9;
	public JLabel lbl_lista_1_1;
	public JLabel lbl_lista_1_2;
	public JLabel lbl_lista_1_3;
	public JLabel lbl_lista_1_4;
	public JLabel lbl_lista_1_5;
	public JLabel lbl_lista_1_6;
	public JLabel lbl_lista_1_7;
	public JLabel lbl_lista_1_8;
	public JLabel lbl_lista_1_9;
	private JTextField txt_buscar;
	private Button button_10;
	public JLabel lbl_id_vh;
	private Button button_11;
	/**
	 * Create the panel.
	 */
	public index() {
		setBackground(SystemColor.activeCaption);
		setLayout(null);
		
		lista = new JPanel();
		lista.setBackground(SystemColor.activeCaption);
		lista.setBorder(new TitledBorder(null, "Lista de veh\u00EDculos", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		lista.setBounds(10, 11, 906, 648);
		add(lista);
		lista.setLayout(null);
		
		lbl_lista_1 = new JLabel("");
		lbl_lista_1.setBounds(34, 22, 260, 170);
		lista.add(lbl_lista_1);
		
		lbl_lista_2 = new JLabel("");
		lbl_lista_2.setBounds(326, 22, 260, 170);
		lista.add(lbl_lista_2);
		
		lbl_lista_3 = new JLabel("");
		lbl_lista_3.setBounds(620, 22, 260, 170);
		lista.add(lbl_lista_3);
		
		lbl_lista_4 = new JLabel("");
		lbl_lista_4.setBounds(34, 222, 260, 170);
		lista.add(lbl_lista_4);
		
		lbl_lista_5 = new JLabel("");
		lbl_lista_5.setBounds(326, 222, 260, 170);
		lista.add(lbl_lista_5);
		
		lbl_lista_6 = new JLabel("");
		lbl_lista_6.setBounds(620, 222, 260, 170);
		lista.add(lbl_lista_6);
		
		lbl_lista_7 = new JLabel("");
		lbl_lista_7.setBounds(34, 423, 260, 170);
		lista.add(lbl_lista_7);
		
		lbl_lista_8 = new JLabel("");
		lbl_lista_8.setBounds(326, 423, 260, 170);
		lista.add(lbl_lista_8);
		
		lbl_lista_9 = new JLabel("");
		lbl_lista_9.setBounds(620, 434, 260, 170);
		lista.add(lbl_lista_9);
		
		lbl_lista_1_1 = new JLabel("");
		lbl_lista_1_1.setBounds(118, 197, 46, 14);
		lista.add(lbl_lista_1_1);
		
		lbl_lista_1_2 = new JLabel("");
		lbl_lista_1_2.setBounds(421, 197, 46, 14);
		lista.add(lbl_lista_1_2);
		
		lbl_lista_1_3 = new JLabel("");
		lbl_lista_1_3.setBounds(695, 197, 46, 14);
		lista.add(lbl_lista_1_3);
		
		lbl_lista_1_4 = new JLabel("");
		lbl_lista_1_4.setBounds(118, 409, 46, 14);
		lista.add(lbl_lista_1_4);
		
		lbl_lista_1_5 = new JLabel("");
		lbl_lista_1_5.setBounds(421, 409, 46, 14);
		lista.add(lbl_lista_1_5);
		
		lbl_lista_1_6 = new JLabel("");
		lbl_lista_1_6.setBounds(695, 409, 46, 14);
		lista.add(lbl_lista_1_6);
		
		lbl_lista_1_7 = new JLabel("");
		lbl_lista_1_7.setBounds(118, 604, 46, 14);
		lista.add(lbl_lista_1_7);
		
		lbl_lista_1_8 = new JLabel("");
		lbl_lista_1_8.setBounds(421, 604, 46, 14);
		lista.add(lbl_lista_1_8);
		
		lbl_lista_1_9 = new JLabel("");
		lbl_lista_1_9.setBounds(695, 604, 46, 14);
		lista.add(lbl_lista_1_9);
		
		txt_buscar = new JTextField();
		txt_buscar.setBounds(51, 617, 113, 20);
		lista.add(txt_buscar);
		txt_buscar.setColumns(10);
		
		JButton btnNewButton = new JButton("Buscar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id_vh = txt_buscar.getText().toString();
				lg.getDatosVH(id_vh);
			}
		});
		btnNewButton.setBounds(205, 616, 89, 23);
		lista.add(btnNewButton);
		
		button_11 = new Button("Cerrar sesi\u00F3n");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(false);
				registro.setVisible(false);
				vender.setVisible(false);
				lista.setVisible(false);
				login.setVisible(true);
			}
		});
		button_11.setFont(new Font("Arial", Font.BOLD, 14));
		button_11.setBackground(new Color(50, 205, 50));
		button_11.setBounds(786, 610, 110, 29);
		lista.add(button_11);
		
		vehiculo = new JPanel();
		vehiculo.setBackground(SystemColor.activeCaption);
		vehiculo.setBorder(new TitledBorder(null, "Veh\u00EDculo", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		vehiculo.setBounds(10, 11, 906, 648);
		add(vehiculo);
		vehiculo.setLayout(null);
		
		lbl_datos_vh_marca = new JLabel("");
		lbl_datos_vh_marca.setBounds(528, 48, 347, 23);
		vehiculo.add(lbl_datos_vh_marca);
		
		button_1 = new Button("Comprar");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lg.saveCompra(lbl_cedula.getText().toString(), lbl_id_vh.getText().toString());
			}
		});
		button_1.setFont(new Font("Arial", Font.BOLD, 14));
		button_1.setBackground(new Color(50, 205, 50));
		button_1.setBounds(627, 466, 86, 29);
		vehiculo.add(button_1);
		
		lbl_datos_vh_modelo = new JLabel("");
		lbl_datos_vh_modelo.setBounds(528, 82, 347, 23);
		vehiculo.add(lbl_datos_vh_modelo);
		
		lbl_datos_vh_anio = new JLabel("");
		lbl_datos_vh_anio.setBounds(528, 116, 347, 23);
		vehiculo.add(lbl_datos_vh_anio);
		
		lbl_datos_vh_kilometraje = new JLabel("");
		lbl_datos_vh_kilometraje.setBounds(528, 150, 347, 23);
		vehiculo.add(lbl_datos_vh_kilometraje);
		
		lbl_datos_vh_nduenos = new JLabel("");
		lbl_datos_vh_nduenos.setBounds(528, 184, 347, 23);
		vehiculo.add(lbl_datos_vh_nduenos);
		
		lbl_datos_vh_aire_acon = new JLabel("");
		lbl_datos_vh_aire_acon.setBounds(528, 218, 347, 23);
		vehiculo.add(lbl_datos_vh_aire_acon);
		
		lbl_datos_vh_tapiceria = new JLabel("");
		lbl_datos_vh_tapiceria.setBounds(528, 252, 347, 23);
		vehiculo.add(lbl_datos_vh_tapiceria);
		
		lbl_datos_vh_pintura = new JLabel("");
		lbl_datos_vh_pintura.setBounds(528, 286, 347, 23);
		vehiculo.add(lbl_datos_vh_pintura);
		
		lbl_datos_vh_carroceria = new JLabel("");
		lbl_datos_vh_carroceria.setBounds(528, 320, 347, 23);
		vehiculo.add(lbl_datos_vh_carroceria);
		
		lbl_datos_vh_choques = new JLabel("");
		lbl_datos_vh_choques.setBounds(528, 354, 347, 23);
		vehiculo.add(lbl_datos_vh_choques);
		
		lbl_datos_vh_valor_venta = new JLabel("");
		lbl_datos_vh_valor_venta.setBounds(528, 388, 347, 23);
		vehiculo.add(lbl_datos_vh_valor_venta);
		
		lbl_imagen_vh = new JLabel("");
		lbl_imagen_vh.setIcon(new ImageIcon(index.class.getResource("/img/car.png")));
		lbl_imagen_vh.setBounds(58, 150, 276, 261);
		vehiculo.add(lbl_imagen_vh);
		
		button_2 = new Button("Cotizar");
		button_2.setFont(new Font("Arial", Font.BOLD, 14));
		button_2.setBackground(new Color(50, 205, 50));
		button_2.setBounds(732, 466, 86, 29);
		vehiculo.add(button_2);
		
		button_3 = new Button("Cerrar sesi\u00F3n");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(false);
				registro.setVisible(false);
				vender.setVisible(false);
				login.setVisible(true);
			}
		});
		button_3.setFont(new Font("Arial", Font.BOLD, 14));
		button_3.setBackground(new Color(50, 205, 50));
		button_3.setBounds(102, 609, 110, 29);
		vehiculo.add(button_3);
		
		button_4 = new Button("Vender");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(false);
				registro.setVisible(false);
				vender.setVisible(true);
				login.setVisible(false);
			}
		});
		button_4.setFont(new Font("Arial", Font.BOLD, 14));
		button_4.setBackground(new Color(112, 128, 144));
		button_4.setBounds(10, 609, 86, 29);
		vehiculo.add(button_4);
		
		lbl_username = new JLabel("");
		lbl_username.setFont(new Font("Arial", Font.BOLD, 16));
		lbl_username.setBounds(218, 609, 130, 29);
		vehiculo.add(lbl_username);
		
		lbl_datos_valor_venta_desc = new JLabel("");
		lbl_datos_valor_venta_desc.setBounds(528, 420, 347, 23);
		vehiculo.add(lbl_datos_valor_venta_desc);
		
		button_10 = new Button("Volver");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(false);
				registro.setVisible(false);
				vender.setVisible(false);
				login.setVisible(false);
				lista.setVisible(true);
			}
		});
		button_10.setFont(new Font("Arial", Font.BOLD, 14));
		button_10.setBackground(new Color(112, 128, 144));
		button_10.setBounds(810, 609, 86, 29);
		vehiculo.add(button_10);
		
		lbl_id_vh = new JLabel("");
		lbl_id_vh.setBounds(0, 0, 46, 14);
		vehiculo.add(lbl_id_vh);
		lbl_id_vh.setVisible(false);
		
		vender = new JPanel();
		vender.setBackground(SystemColor.activeCaption);
		vender.setBorder(new TitledBorder(null, "Vender", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		vender.setBounds(10, 11, 906, 648);
		add(vender);
		vender.setLayout(null);
		
		txt_marca = new TextField();
		txt_marca.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
				lbl_marca_v.setText("Marca: " + txt_marca.getText().toString());
			}
		});
		txt_marca.setBounds(108, 87, 147, 22);
		vender.add(txt_marca);
		
		txt_modelo = new TextField();
		txt_modelo.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {
				lbl_modelo_v.setText("Modelo: "+txt_modelo.getText().toString());
			}
		});
		txt_modelo.setBounds(108, 127, 147, 22);
		
		vender.add(txt_modelo);
		lbl_anio_v = new JLabel("");
		lbl_anio_v.setBounds(393, 442, 118, 14);
		vender.add(lbl_anio_v);
		
		cmb_anio = new JComboBox();
		cmb_anio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String valor = cmb_anio.getSelectedItem().toString();
				lbl_anio_v.setText("A�o: "+valor);
			}
		});
		cmb_anio.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {

			}
		});
		cmb_anio.setModel(new DefaultComboBoxModel(new String[] {"A\u00F1o", "1950", "1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958", "1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966", "1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023"}));
		cmb_anio.setBounds(108, 171, 147, 22);
		vender.add(cmb_anio);
		
		txt_num_duenos = new JSpinner();
		txt_num_duenos.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				lbl_num_duenos_v.setText("Numero de due�os: "+txt_num_duenos.getValue().toString());
			}
		});
		txt_num_duenos.setModel(new SpinnerNumberModel(0, 0, 100, 1));
		txt_num_duenos.setBounds(139, 295, 52, 20);
		vender.add(txt_num_duenos);
		
		cmb_choques = new JComboBox();
		cmb_choques.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_choques_v.setText("Choques: "+cmb_choques.getSelectedItem().toString());
			}
		});
		cmb_choques.setModel(new DefaultComboBoxModel(new String[] {"Choques", "Si", "No"}));
		cmb_choques.setBounds(108, 341, 147, 22);
		vender.add(cmb_choques);
		
		cmb_aire_acon = new JComboBox();
		cmb_aire_acon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_aire_acon_v.setText("Aire acondicionado: "+cmb_aire_acon.getSelectedItem().toString());
			}
		});
		cmb_aire_acon.setModel(new DefaultComboBoxModel(new String[] {"Aire Acondicionado", "Si", "No"}));
		cmb_aire_acon.setBounds(108, 374, 147, 22);
		vender.add(cmb_aire_acon);
		
		cmb_tapiceria = new JComboBox();
		cmb_tapiceria.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_tapiceria_v.setText("Tapiceria: "+cmb_tapiceria.getSelectedItem().toString());
			}
		});
		cmb_tapiceria.setModel(new DefaultComboBoxModel(new String[] {"Tapiceria", "Mala", "Regular", "Excelente"}));
		cmb_tapiceria.setBounds(108, 413, 147, 22);
		vender.add(cmb_tapiceria);
		
		cmb_pintura = new JComboBox();
		cmb_pintura.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_pintura_v.setText("Pintura: "+cmb_pintura.getSelectedItem().toString());
			}
		});
		cmb_pintura.setModel(new DefaultComboBoxModel(new String[] {"Pintura", "Mala", "Regular", "Excelente"}));
		cmb_pintura.setBounds(108, 451, 147, 22);
		vender.add(cmb_pintura);
		
		cmb_carroceria = new JComboBox();
		cmb_carroceria.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_carroceria_v.setText("Carroceria: "+cmb_carroceria.getSelectedItem().toString());
			}
		});
		cmb_carroceria.setModel(new DefaultComboBoxModel(new String[] {"Carroceria", "Mala", "Regular", "Excelente"}));
		cmb_carroceria.setBounds(108, 489, 147, 22);
		vender.add(cmb_carroceria);
		
		Button button_8 = new Button("Guardar");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lg.saveVH();
			}
		});
		button_8.setBounds(108, 560, 147, 22);
		vender.add(button_8);
		
		JButton btnNewButton_1 = new JButton("Cargar imagen");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser j = new JFileChooser();
		        FileNameExtensionFilter fil = new FileNameExtensionFilter("JPG, PNG & GIF","jpg","png","gif");
		        j.setFileFilter(fil);
		        
		        int s = j.showOpenDialog(vender);
		        Icon icono = null;
		        if(s == JFileChooser.APPROVE_OPTION){
		        	ruta = j.getSelectedFile().getAbsolutePath();
		        	ImageIcon fot = new ImageIcon(ruta);
		        	System.out.println(ruta);
		        	icono = new ImageIcon(fot.getImage().getScaledInstance(lbl_imagen.getWidth(), lbl_imagen.getHeight(), Image.SCALE_DEFAULT));
		        }
		        lbl_imagen.setIcon(icono);
			}
		});
		btnNewButton_1.setBounds(108, 522, 147, 23);
		vender.add(btnNewButton_1);
		
		lbl_imagen = new JLabel("");
		lbl_imagen.setBounds(393, 56, 384, 289);
		vender.add(lbl_imagen);
		
		lblNewLabel_10 = new JLabel("Previsualizaci\u00F3n");
		lblNewLabel_10.setBounds(537, 31, 136, 14);
		vender.add(lblNewLabel_10);
		
		lbl_marca_v = new JLabel("");
		lbl_marca_v.setBounds(393, 392, 147, 14);
		vender.add(lbl_marca_v);
		
		lbl_modelo_v = new JLabel("");
		lbl_modelo_v.setBounds(393, 417, 118, 14);
		vender.add(lbl_modelo_v);
		
		lbl_kilometraje_v = new JLabel("");
		lbl_kilometraje_v.setBounds(393, 469, 184, 14);
		vender.add(lbl_kilometraje_v);
		
		lbl_num_duenos_v = new JLabel("");
		lbl_num_duenos_v.setBounds(393, 493, 184, 14);
		vender.add(lbl_num_duenos_v);
		
		lbl_choques_v = new JLabel("");
		lbl_choques_v.setBounds(393, 522, 118, 14);
		vender.add(lbl_choques_v);
		
		lbl_aire_acon_v = new JLabel("");
		lbl_aire_acon_v.setBounds(587, 413, 190, 14);
		vender.add(lbl_aire_acon_v);
		
		lbl_tapiceria_v = new JLabel("");
		lbl_tapiceria_v.setBounds(587, 438, 154, 14);
		vender.add(lbl_tapiceria_v);
		
		lbl_pintura_v = new JLabel("");
		lbl_pintura_v.setBounds(587, 463, 154, 14);
		vender.add(lbl_pintura_v);
		
		lbl_carroceria_v = new JLabel("");
		lbl_carroceria_v.setBounds(587, 488, 154, 14);
		vender.add(lbl_carroceria_v);
		
		JLabel lblNewLabel_11 = new JLabel("Marca");
		lblNewLabel_11.setBounds(37, 95, 46, 14);
		vender.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Modelo");
		lblNewLabel_12.setBounds(37, 135, 65, 14);
		vender.add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("Kilometraje");
		lblNewLabel_13.setBounds(37, 218, 65, 14);
		vender.add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("Valor venta");
		lblNewLabel_14.setBounds(37, 256, 65, 14);
		vender.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("N\u00FAmero due\u00F1os");
		lblNewLabel_15.setBounds(37, 298, 92, 14);
		vender.add(lblNewLabel_15);
		
		lbl_valor_venta = new JLabel("");
		lbl_valor_venta.setBounds(587, 522, 241, 14);
		vender.add(lbl_valor_venta);
		
		Button button_3_1 = new Button("Cerrar sesi\u00F3n");
		button_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(false);
				registro.setVisible(false);
				vender.setVisible(false);
				login.setVisible(true);
			}
		});
		button_3_1.setFont(new Font("Arial", Font.BOLD, 14));
		button_3_1.setBackground(new Color(50, 205, 50));
		button_3_1.setBounds(101, 609, 110, 29);
		vender.add(button_3_1);
		
		button_9 = new Button("Volver");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(true);
				registro.setVisible(false);
				vender.setVisible(false);
				login.setVisible(false);
			}
		});
		button_9.setFont(new Font("Arial", Font.BOLD, 14));
		button_9.setBackground(new Color(112, 128, 144));
		button_9.setBounds(10, 609, 86, 29);
		vender.add(button_9);
		
		txt_valor_venta = new JSpinner();
		txt_valor_venta.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				lbl_valor_venta.setText("Valor de venta: "+txt_valor_venta.getValue().toString());
			}
		});
		txt_valor_venta.setModel(new SpinnerNumberModel(new Float(0), new Float(0), null, new Float(1)));
		txt_valor_venta.setBounds(108, 253, 147, 20);
		vender.add(txt_valor_venta);
		
		txt_kilometraje = new JSpinner();
		txt_kilometraje.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				lbl_kilometraje_v.setText("Kilometraje: "+txt_kilometraje.getValue().toString());
			}
		});
		txt_kilometraje.setModel(new SpinnerNumberModel(new Float(0), new Float(0), null, new Float(1)));
		txt_kilometraje.setBounds(108, 215, 147, 20);
		vender.add(txt_kilometraje);
		
		registro = new JPanel();
		registro.setBorder(new TitledBorder(null, "Registro", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		registro.setBackground(SystemColor.activeCaption);
		registro.setBounds(10, 11, 906, 648);
		add(registro);
		registro.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(index.class.getResource("/img/resume.png")));
		lblNewLabel_3.setBounds(390, 30, 133, 161);
		registro.add(lblNewLabel_3);
		
		txt_cid = new TextField();
		txt_cid.setBounds(326, 202, 248, 28);
		registro.add(txt_cid);
		
		txt_nombres = new TextField();
		txt_nombres.setBounds(326, 255, 248, 28);
		registro.add(txt_nombres);
		
		txt_apellidos = new TextField();
		txt_apellidos.setBounds(326, 311, 248, 28);
		registro.add(txt_apellidos);
		
		txt_username_reg = new TextField();
		txt_username_reg.setBounds(326, 366, 248, 28);
		registro.add(txt_username_reg);
		
		txt_password_reg = new JPasswordField();
		txt_password_reg.setBounds(326, 423, 248, 28);
		registro.add(txt_password_reg);
		
		txt_password_reg_conf = new JPasswordField();
		txt_password_reg_conf.setBounds(326, 481, 248, 28);
		registro.add(txt_password_reg_conf);
		
		Button button_5 = new Button("Registrarse");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lg.register();
			}
		});
		button_5.setFont(new Font("Arial", Font.BOLD, 14));
		button_5.setBackground(new Color(50, 205, 50));
		button_5.setBounds(397, 546, 101, 28);
		registro.add(button_5);
		
		button_7 = new Button("Tienes cuenta? Inicia sesi\u00F3n.");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(false);
				login.setVisible(true);
				registro.setVisible(false);
			}
		});
		button_7.setForeground(Color.BLACK);
		button_7.setFont(new Font("Arial", Font.PLAIN, 14));
		button_7.setBackground(new Color(255, 127, 80));
		button_7.setBounds(326, 591, 248, 31);
		registro.add(button_7);
		
		lblNewLabel_4 = new JLabel("C\u00E9dula");
		lblNewLabel_4.setBounds(326, 182, 46, 14);
		registro.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("Nombres");
		lblNewLabel_5.setBounds(326, 236, 60, 14);
		registro.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("Apellidos");
		lblNewLabel_6.setBounds(326, 289, 70, 14);
		registro.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("Nombre de usuario");
		lblNewLabel_7.setBounds(326, 345, 133, 14);
		registro.add(lblNewLabel_7);
		
		lblNewLabel_8 = new JLabel("Contrase\u00F1a");
		lblNewLabel_8.setBounds(326, 400, 82, 14);
		registro.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("Confirmar contrase\u00F1a");
		lblNewLabel_9.setBounds(326, 462, 133, 14);
		registro.add(lblNewLabel_9);
		
		login = new JPanel();
		login.setBackground(SystemColor.activeCaption);
		login.setBorder(new TitledBorder(null, "Login", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		login.setBounds(10, 11, 906, 648);
		add(login);
		login.setLayout(null);
		
		txt_username = new TextField();
		txt_username.setBounds(367, 257, 179, 31);
		login.add(txt_username);
		
		Button button = new Button("Ingresar");
		button.setFont(new Font("Arial", Font.PLAIN, 14));
		button.setForeground(SystemColor.window);
		button.setBackground(SystemColor.activeCaptionText);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lg.login();
			}
		});
		button.setBounds(412, 371, 81, 31);
		login.add(button);
		
		txt_password = new JPasswordField();
		txt_password.setBounds(367, 315, 179, 31);
		login.add(txt_password);
		
		lblNewLabel = new JLabel("Nombre de usuario");
		lblNewLabel.setBounds(367, 237, 126, 14);
		login.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Contrase\u00F1a");
		lblNewLabel_1.setBounds(367, 299, 70, 14);
		login.add(lblNewLabel_1);
		
		icono = new JLabel("");
		icono.setIcon(new ImageIcon(index.class.getResource("/img/userj.png")));
		icono.setBounds(388, 88, 127, 138);
		login.add(icono);
		
		button_6 = new Button("No tienes cuenta? Registrate.");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vehiculo.setVisible(false);
				login.setVisible(false);
				registro.setVisible(true);
			}
		});
		button_6.setForeground(new Color(0, 0, 0));
		button_6.setFont(new Font("Arial", Font.PLAIN, 14));
		button_6.setBackground(new Color(255, 127, 80));
		button_6.setBounds(337, 418, 241, 31);
		login.add(button_6);
		
		lbl_cedula = new JLabel("");
		lbl_cedula.setBounds(0, 0, 46, 14);
		lbl_cedula.setVisible(false);
		login.add(lbl_cedula);
		
		lg = new logica(this);
		lg.getDatosVH("1");
		lg.cargar_lista();
		if(vender.isVisible()) {
			login.setVisible(false);
			registro.setVisible(false);
			vehiculo.setVisible(false);
			lista.setVisible(false);
		}
		if(lista.isVisible()) {
			login.setVisible(false);
			registro.setVisible(false);
			vehiculo.setVisible(false);
			vender.setVisible(false);
		}
		if(login.isVisible()) {
			lista.setVisible(false);
			registro.setVisible(false);
			vehiculo.setVisible(false);
			vender.setVisible(false);
		}
		if(vehiculo.isVisible()) {
			lista.setVisible(false);
			registro.setVisible(false);
			login.setVisible(false);
			vender.setVisible(false);
		}
		if(registro.isVisible()) {
			lista.setVisible(false);
			vehiculo.setVisible(false);
			login.setVisible(false);
			vender.setVisible(false);
		}
		cargaP();
	}
	public void cargaP() {
		lista.setVisible(false);
		vehiculo.setVisible(false);
		login.setVisible(true);
		vender.setVisible(false);
		registro.setVisible(false);
	}
}
